#ifndef BFC_DUMPBF_HPP
#define BFC_DUMPBF_HPP

void DumpBF(int argc, char** argv);

#endif // BFC_DUMPBF_HPP

#ifndef BFC_COMMON_HPP
#define BFC_COMMON_HPP

#include <omp.h>
using namespace std;

#define BFC_VERSION "BFCounter 1.0"
#define BFC_BUG_EMAIL "pmelsted@gmail.com"

#endif // BFC_COMMON_HPP

#ifndef BFC_CountBF
#define BFC_CountBF

void CountBF(int argc, char** argv);

#endif // BFC_CountBF
